# Project for a client

<h2>Client: Roskilde SUP Klub</h2>

<h2>Needs:</h2>
They need a website containing basic information about prices and such. The main goal, however, is to create a login page for the members of the club for them to reserve boards they use for paddling to make it easier to see if a board is reserved or available.  
