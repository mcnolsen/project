function registerUserMysql() {
    var mysql = require('mysql');

    var con = mysql.createConnection({
        host: "174.138.180.42",
        user: "blasfame_project",
        password: "OzItpkrlq[yv",
        database: "blasfame_project"
    });
    con.connect();

    //Objekt med nødvendig user data. Den finder dataen fra det indtastede på siden.
    var userData = {
        username: document.getElementById("user").value,
        password: document.getElementById("password").value,
        admin: document.getElementById("admin").value,
    };
    var sql = "INSERT INTO 'users' ('username', 'password', 'admin') VALUES ('username', 'password', 'admin')";
    con.query(sql, (err, result) => {
        if (err) {
            console.error(err);
            return;
        }
        else {
            console.error(result);
        }
    })
}

function registerUserCheckMysql() {
    //Objekt med nødvendig user data. Den finder dataen fra det indtastede på siden.
    var userData = {
        username: document.getElementById("user").value,
        password: document.getElementById("password").value,
        admin: document.getElementById("admin").value,
    };


}
