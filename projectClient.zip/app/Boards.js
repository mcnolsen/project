Class Boards {
    constructor(type) {
        this.type=type;
    }
}